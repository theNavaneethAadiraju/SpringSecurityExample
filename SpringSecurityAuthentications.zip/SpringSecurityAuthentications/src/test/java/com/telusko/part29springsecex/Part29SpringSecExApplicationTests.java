package com.telusko.part29springsecex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Part29SpringSecExApplicationTests {

    @Test
    void contextLoads() {
    }

}
