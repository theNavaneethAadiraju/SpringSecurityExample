package com.demo.security.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.security.model.Person;

import java.util.ArrayList;
import java.util.List;

@RestController
public class PersonController {

    private List<Person> persons = new ArrayList<>(
            List.of(
                    new Person(1, "Navin", 60),
                    new Person(2, "Kiran", 65)
            ));


    @GetMapping("/persons")
    public List<Person> getStudents() {
        return persons;
    }

    @GetMapping("/csrf-token")
    public CsrfToken getCsrfToken(HttpServletRequest request) {
        return (CsrfToken) request.getAttribute("_csrf");


    }


    @PostMapping("/persons")
    public Person addStudent(@RequestBody Person person) {
        persons.add(person);
        return person;
    }

}
