package com.demo.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.demo.security.model.Users;
import com.demo.security.repo.UserRepo;

@Service
public class UserService {
	
	
	@Autowired
	private UserRepo repo;
	
	
	private BCryptPasswordEncoder encoder= new BCryptPasswordEncoder(10);
	
	
	public Users registeruser(Users user) {
		user.setPassword(encoder.encode(user.getPassword()));
		return repo.save(user);
	}

}
