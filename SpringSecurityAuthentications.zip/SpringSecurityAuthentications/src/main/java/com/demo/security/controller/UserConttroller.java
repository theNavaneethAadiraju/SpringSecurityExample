package com.demo.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.security.model.Users;
import com.demo.security.service.UserService;

@RestController
public class UserConttroller {
	
	@Autowired
	private UserService userservice;
	
	
	@PostMapping("/registeruser")
	public Users register(@RequestBody Users user) {
		
		return userservice.registeruser(user);
	}

}
