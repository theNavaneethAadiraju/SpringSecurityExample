package com.example.SpringSecurityExample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	
	@Autowired
	private UserService userservice;
	
	private BCryptPasswordEncoder encode= new BCryptPasswordEncoder(10);
	
	@PostMapping("/saveuser")
	public Users saveusers(@RequestBody Users user) {
		user.setUser_password(encode.encode(user.getUser_password()));
		return userservice.registeruser(user);
		
	}
	
	
	@PostMapping("/loginuser")
	public String getLogin(@RequestBody Users u) {
		return "Sucess";
	}

}
