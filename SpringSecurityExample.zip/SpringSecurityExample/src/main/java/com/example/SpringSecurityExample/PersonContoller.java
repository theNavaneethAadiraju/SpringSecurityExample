package com.example.SpringSecurityExample;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class PersonContoller {
	
	
	private List <Person> p = new ArrayList<>(List.of(
			new Person(1,"nav",230),
			new Person(2,"lak", 33),
			new Person (3,"sikim",455)
			));
	
	
	@GetMapping("/getperson")
	private List<Person> getperonslist(){
		return p;
	}
	
	
	@PostMapping("/addperosn")
	private Person addPerson (@RequestBody Person per) {
		p.add(per);
		return per;
	}
	
	
	@GetMapping("getcsrftoken")
	private CsrfToken getcsrftoken(HttpServletRequest http) {
		return (CsrfToken) http.getAttribute("_csrf");
		
	}

}
