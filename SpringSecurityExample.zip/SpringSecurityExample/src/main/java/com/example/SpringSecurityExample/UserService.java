package com.example.SpringSecurityExample;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	@Autowired
	private UserRepository repo;
	
	public Users registeruser(Users user) {
		return repo.save(user);
		
	}
	

}
